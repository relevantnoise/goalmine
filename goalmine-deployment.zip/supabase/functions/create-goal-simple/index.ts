import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    // Parse request
    const body = await req.json();
    console.log('🔍 Received request body:', JSON.stringify(body, null, 2));
    
    const { user_id, title, tone, time_of_day } = body;

    // Basic validation
    if (!user_id || !title || !tone || !time_of_day) {
      console.error('❌ Missing required fields:', { user_id: !!user_id, title: !!title, tone: !!tone, time_of_day: !!time_of_day });
      return new Response(JSON.stringify({ 
        success: false, 
        error: "Missing required fields: user_id, title, tone, time_of_day" 
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 400,
      });
    }

    console.log('✅ Validation passed, creating goal for user:', user_id);

    // Create Supabase client
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? ""
    );

    // Parse the full request body to get all fields
    const { description, target_date } = body;

    // Insert goal with all required fields
    const { data, error } = await supabase
      .from('goals')
      .insert([{
        user_id,
        title,
        description: description || null,
        target_date: target_date || null,
        tone,
        time_of_day,
        streak_count: 0,
        is_active: true,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      }])
      .select()
      .single();

    if (error) {
      console.error('❌ Database error creating goal:', error);
      console.error('❌ Error details:', { 
        code: error.code, 
        message: error.message, 
        details: error.details,
        hint: error.hint 
      });
      return new Response(JSON.stringify({ 
        success: false, 
        error: `Database error: ${error.message}`,
        code: error.code,
        details: error.details
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      });
    }

    return new Response(JSON.stringify({ 
      success: true, 
      goal: data 
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 200,
    });

  } catch (error) {
    return new Response(JSON.stringify({ 
      success: false, 
      error: error.message || "Unknown error" 
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
      status: 500,
    });
  }
});