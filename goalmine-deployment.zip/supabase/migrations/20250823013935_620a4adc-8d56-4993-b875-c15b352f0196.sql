-- Clear all existing data from tables
DELETE FROM motivation_history;
DELETE FROM goals;
DELETE FROM subscribers;
DELETE FROM profiles;
DELETE FROM clerk_users;