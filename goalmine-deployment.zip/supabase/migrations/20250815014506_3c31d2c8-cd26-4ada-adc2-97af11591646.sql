-- Temporarily disable RLS on goals table to test insertion
ALTER TABLE public.goals DISABLE ROW LEVEL SECURITY;