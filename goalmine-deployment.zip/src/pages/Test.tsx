const Test = () => {
  return <div>Test page works!</div>;
};

export default Test;